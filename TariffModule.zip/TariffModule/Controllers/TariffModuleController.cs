﻿using Microsoft.AspNetCore.Mvc;

namespace TariffModule.Controllers
{
	public class TariffModuleController : Controller
	{
		public IActionResult Index()
		{
			return View();
		}
	}
}
