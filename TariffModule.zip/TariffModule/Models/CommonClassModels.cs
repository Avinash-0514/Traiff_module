﻿namespace TariffModule.Models
{
	public class CommonClassModels
	{
	}
}
