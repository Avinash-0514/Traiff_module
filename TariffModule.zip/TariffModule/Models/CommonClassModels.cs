﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace TariffModule.Models
{
    public class AS_SHIPMENT_CURRENCY
    {
        public string currency { get; set; }
        public long? currencyKey { get; set; }
    }
    public class AS_SHIPMENT_RATE_DETAILS
    {
        public string rateName { get; set; }
        public long? buyRate { get; set; }
        public long? sellRate { get; set; }
        public DateTime validTo { get; set; }
        public DateTime validFrom { get; set; }
    }
    public class AS_SHIPMENT_PACKAGE_DETAILS
    {
        public string packageType { get; set; }
        public string packageCode { get; set; }
    }
    public class AS_SHIPMENT_CARGO_DETAILS
    {
        public string cargoType { get; set; }
        public string cargoCode { get; set; }
        public string hsCode { get; set; }
        public string hsCodeName { get; set; }
        public bool IsDG { get; set; }
		public bool IsReefer { get; set; }
		public bool IsOOG { get; set; }
	}
    public class AS_SHIPMENT_DIMENSIONS
    {
        public long? length { get; set; }
		public long? width { get; set; }
		public long? height { get; set; }
		public long? quantity { get; set; }
		public long? cbm { get; set; }
		public long? volWeight { get; set; }
		public long? ChWeight { get; set; }
        public long? grossWeight { get; set;}
		public long? netWeight { get; set; }
		public string UOM { get; set; }
	}
    public class AS_SHIPMENT_MODE // AIR,SEA
    {
        public string ShipmentMode { get; set; }
		public long? ShipmentKey { get; set; }
	}
    public class AS_SHIPMENT_TYPE //LCL,FCL
    {
		public string shipmentType{ get; set; }
		public long? ShipmentTypeKey { get; set; }
	}
    public class AS_SHIPMENT_COMMON_CODE
    {
        public string portCode { get; set; }
		public string portName { get; set; }
		public long? portKey { get; set; }
		public string CountryCode { get; set; }
		public string CountryName { get; set; }
		public long? CountryKey { get; set; }
		public string CityCode { get; set; }
		public string CityName { get; set; }
		public long? CityKey { get; set; }
        public long? pinCode{ get; set; }
        public string Address { get; set; }

    }
}