﻿namespace TariffModule.Models.Service.Interfaces
{
	public interface InService
	{
	}
}
