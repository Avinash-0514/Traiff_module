﻿using System.Threading.Tasks;
using TARIFF_PORTAL.Models;

namespace TariffModule.Models.Service
{
	public interface IService
	{
		public Task<Result> GetLovData(string value, string key);
		public Task<Result> GetTariffData();
		public Task<Result> GetTransitTime();
		public Task<Result> GetPackageTypes();
		public Task<Result> GetShipmentDetailsByID();
		public Task<Result> GetShipmentDetails();

	}
}
