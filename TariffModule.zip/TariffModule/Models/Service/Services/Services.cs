﻿namespace TariffModule.Models.Service.Services
{
	public class Services
	{
	}
}
