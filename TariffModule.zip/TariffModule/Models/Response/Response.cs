﻿namespace TariffModule.Models.Response
{
	public class Response
	{
	}
}
