﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace TariffModule.Models
{
	public class Request<T>
	{
        public T Data { get; set; }
		public string product { get; set; }
	}
}
