﻿
namespace TariffModule.Models.Request
{
	public class Request
	{
	}
}
